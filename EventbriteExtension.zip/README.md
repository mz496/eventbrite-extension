# Eventbrite Chrome Extension

Displays nearby popular events pulled from the Eventbrite API for a given location.

To build the project, run `source build.sh`, and `npm install -g browserify` if needed.
