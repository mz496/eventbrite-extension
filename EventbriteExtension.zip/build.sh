#!/usr/bin/env bash
browserify -t reactify public/js/main.jsx -o public/bundle.js